A=990
L=140+150
V=1100
a=A/3+L/3+V/3
l=A/3+L/3+V/3
v=A/3+L/3+V/3
print('the due of Abhiraj is',a-A)
print('the due of Leon is',l-L)
print('the due of Vigyan is',v-V)



