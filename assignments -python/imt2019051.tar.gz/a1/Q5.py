a=(str)(input())
b=(int)(input())
if a.lower() == "january":
        b=(int)(input("Enter your date in january:"))
        if b>=1 and b<=20:
            print("Capricorn")
        elif b>=21 and b<=31:
            print("Aquarius")
elif a.lower() == "february":
        b=(int)(input("Enter your date in february:"))
        if b>=1 and b<=19:
            print("Aquarius")
        elif b>=20 and b<=29:
            print("pisces")
elif a.lower() == "march":
        b=(int)(input("Enter your date in march:"))
        if b>=1 and b<=20:
            print("pisces")
        elif b>=21 and b<=31:
            print("aries")
elif a.lower() == "april":
        b=(int)(input("Enter your date in april:"))
        if b>=1 and b<=20:
            print("aries")
        elif b>=21 and b<=30:
            print("taurus")
elif a.lower() == "may":
        b=(int)(input("Enter your date in may:"))
        if b>=1 and b<=20:
            print("taurus")
        elif b>=21 and b<=31:
            print("gemini")
elif a.lower() == "june":
        b=(int)(input("Enter your date in june:"))
        if b>=1 and b<=21:
            print("gemini")
        elif b>=22 and b<=30:
            print("cancer")
elif a.lower() == "july":
        b=(int)(input("Enter your date in july:"))
        if b>=1 and b<=22:
            print("cancer ")
        elif b>=23 and b<=31:
            print("leo")
elif a.lower() == "august":
        b=(int)(input("Enter your date in august:"))
        if b>=1 and b<=23:
            print("leo")
        elif b>=23 and b<=30:
            print("virgo")
elif a.lower() == "september":
        b=(int)(input("Enter your date in september:"))
        if b>=1 and b<=22:
            print("virgo")
        elif b>=23 and b<=31:
            print("libra")
elif a.lower() == "october":
        b=(int)(input("Enter your date in october:"))
        if b>=1 and b<=22:
            print("libra")
        elif b>=22 and b<=30:
            print("scorpio")
elif a.lower() == "november":
        b=(int)(input("Enter your date in november:"))
        if b>=1 and b<=22:
            print("scorpio")
        elif b>=23 and b<=31:
            print("sagattarius")
elif a.lower() == "december":
        b=(int)(input("Enter your date in december:"))
        if b>=1 and b<=21:
            print("sagattarius")
        elif b>=22 and b<=30:
            print("capricorn")

