N=(int)(input())
a=N//200
b=(N-a*200)//50
c=(N-a*200-b*50)//10
d=(N-a*200-b*50-c*10)//5
e=(N-a*200-b*50-c*10-d*5)//2
f=(N-a*200-b*50-c*10-d*5-e*2)
print("the smallest number of notes that will combine to give Rs.N is",a+b+c+d+e+f)
