print('menu:')
print('choice 1 for Addition')
print('choice 2 for Multiplication')
print('choice 3 for Average')
ch=(int)(input())
if ch==1:
    a=(int)(input())
    b=(int)(input())
    r=a+b
    print(r)
elif ch==2:
    a=(int)(input())
    b=(int)(input())
    r=a*b
    print(r)
elif ch==3:
    a=(int)(input())
    b=(int)(input())
    r=(a+b)/2
    print(r)

