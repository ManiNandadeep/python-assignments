import math
a=(int)(input())
b=(int)(input())
if(a>=0 and b>=0):
  c=(int)(math.sqrt(a*a+b*b))
print(c)

