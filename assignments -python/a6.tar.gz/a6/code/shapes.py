class Circle:
    PI=3.1415
    radius=0
    def area(self,r):
        self.radius=r
        return (self.PI)*(self.radius**2)
    def circumference(self,r):
        self.radius=r
        return 2*(self.PI)*(self.radius)
class Rectangle:
    length=0
    breadth=0
    def area(self,l,b):
        self.length=l
        self.breadth=b
        return self.length*self.breadth
    def circumference(self,l,b):
        self.length=l
        self.breadth=b
        return 2*(self.length+self.breadth)
