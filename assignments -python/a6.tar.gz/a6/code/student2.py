class Student:
    rollcount=1
    def __init__(self,name):
        self.name=name
        self.rollNumber=Student.rollcount
        Student.rollcount+=1

        
