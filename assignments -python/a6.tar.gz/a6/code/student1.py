class Student:

    def __init__(self,n,rN):
        self.name=n
        self.rollNumber=rN
