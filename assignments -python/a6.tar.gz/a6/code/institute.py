class Institute:
    def __init__(self,students=[]):
        self.students=students

    def isStudentOf(self,s):
        self.s=s
        for i in range(len(self.students)):
            if s.name==self.students[i].name and s.rollNumber==self.students[i].rollNumber:
                return True
            else:
                return False
    def isAddable(self,s):
        if self.isStudentOf(s) :
            return False
        else:
            for i in range(len(self.students)):
                if s.rollNumber==self.students[i].rollNumber:
                    return False
                return True
    def addStudent(self,s):
        if self.isAddable(s) is True:
            self.students.append(s)
            return True
        else:
            return False

