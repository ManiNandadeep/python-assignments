from hyp_input import *
import math
# Your code - begin
output = math.sqrt(a * a + b * b)
# Your code - end
