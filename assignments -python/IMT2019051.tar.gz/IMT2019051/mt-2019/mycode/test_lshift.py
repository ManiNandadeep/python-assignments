import lshift

if lshift.output == [3,4,5,1,2]:
  print "pass"
else:
  print "fail"
