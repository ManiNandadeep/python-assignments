import hyp

if hyp.output == 5:
  print "pass"
else:
  print "fail"
