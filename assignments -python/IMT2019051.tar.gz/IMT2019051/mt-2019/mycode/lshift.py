from lshift_input import *

# Your code - begin
output = l
while(n > 0):
    x = output.pop(0)
    output.append(x)
    n -= 1
# Your code - end
