import lyear

print lyear.output
if lyear.output == False:
  print "pass"
else:
  print "fail"
