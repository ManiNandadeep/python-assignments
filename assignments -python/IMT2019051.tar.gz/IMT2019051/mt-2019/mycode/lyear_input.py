inp = 3
