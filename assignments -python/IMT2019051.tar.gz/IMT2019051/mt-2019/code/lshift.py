from lshift_input import *

# Your code - begin
m=[]
output=[]
for i in range(n):
    m.append(l[i])
for i in range(n):
    l.pop(0)
for i in range(n):
    l.append(m[i])
output=l[:]
# Your code - end
