import lyear

if lyear.output == False:
  print "pass"
else:
  print "fail"
