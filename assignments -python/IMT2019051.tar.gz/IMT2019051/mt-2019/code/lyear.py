from lyear_input import *

# Your code - begin
if inp%4==0:
    if inp%100==0:
        if inp%400==0:
            output=True
        else:
            output=False
    else:
        output=True
else:
    output=False
# Your code - end
