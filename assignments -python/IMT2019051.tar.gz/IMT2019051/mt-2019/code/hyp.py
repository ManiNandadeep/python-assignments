from hyp_input import *

# Your code - begin
import math
if a>0 and b>0:
    output=math.sqrt(pow(a,2)+pow(b,2))
# Your code - end
