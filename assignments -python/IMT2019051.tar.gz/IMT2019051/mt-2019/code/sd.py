from lshift_input import *

# Your code - begin
import math
def mysum(l):
    s=0
    for i in range(len(l)):
        s+=l[i]
    return s

def average(l):
    s=mysum(l)
    avg=float(s)/len(l)
    return avg

def sqsum(l):
    lst=[x*x for x in l]
    sq_sum=mysum(lst)
    return sq_sum

def sd(l):
    avg=average(l)
    dev=[x-avg for x in l]
    sqdev=sqsum(dev)
    variance=sqdev/float(len(l))
    std_dev=math.sqrt(variance)
    return std_dev
# Your code - end
