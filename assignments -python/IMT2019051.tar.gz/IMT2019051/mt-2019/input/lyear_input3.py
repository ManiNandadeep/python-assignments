inp = 4
