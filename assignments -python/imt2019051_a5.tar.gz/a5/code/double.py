def double(l):
## Your code - begin
    return [2*x for x in l]
## Your code - end
  
if __name__ == "__main__":
  l = [1, 2, 3]
  print "input = ", l
  print double([1, 2, 3])
