# Array printing utility function. Feel free to use.
def printArr(arr, k): 
  for i in range(k): 
    print(str(arr[i]) + " "), 
  print
  
def printSeqUtil(n, k, len1, arr):  
## Your code - begin
    if k>n:
        return      #if k>n there is no arr possible
    else:
        if len1!=k:     #len1 is an variable used for moving across the arr
            if len1!=0:     
                i=arr[len1-1]+1
            else:       #if len1 is equal to 0 impliment the given statements
                i=1
            len1+=1
            while(i<=n):        #ensuring that each element is less than or equal to n
                arr[len1-1]=i
                printSeqUtil(n,k,len1,arr)  
                i+=1
        elif len1==k:           #if len1==k then print arr
            printArr(arr,k)
            return 
## Your code - end

def printSeq(n, k): 
    arr = [0] * k  
    len1 = 0
    printSeqUtil(n, k, len1, arr) 

if __name__ == "__main__":
  n = input("Enter n: ")
  k = input("Enter k: ")
  printSeq(n, k)
