def recurse(ans, n):
## Your code - begin
    if n==0:
        return int((ans+str(n))[-2::-1])    #return the binary representation
    else:
        ans+=str(n%2)
        return recurse(ans,n/2)     #call the function recurse
## Your code - end

def decToBin(n):
  return recurse("", n) 

if __name__ == "__main__":
  n = input("Enter number: ")
  output = decToBin(n)
  print output

