def hello(name):
## Your code - begin
    return  "Hello "+name
## Your code - end
  
if __name__ == "__main__":
  print hello("IIITB")
