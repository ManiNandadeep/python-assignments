def recurse(n, i):
## Your code - begin
    if len(n)!=1 :
        if n[i]!=n[len(n)-1-i]:     #comparing the element of index i with element of index len(n)-i-1
            return False
        elif n[i]==n[len(n)-i-1]:
            if i==len(n)-i-1 or i==len(n)/2 :   
                return True
            else:
                return recurse(n,i+1)
    elif len(n)==1:     #return True if length of the string is 1
        return True

## Your code - end

def isPalindrome(n):
  return recurse(n, 0)
  
if __name__ == '__main__':
	n = raw_input("Enter string: ")
	output = isPalindrome(n)
	print output
