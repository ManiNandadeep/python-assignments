#to write a function named ndiamond() to print numbers in diamond fashion of height 5
def ndiamond():
    rows=1
    while rows<4:
        print' '*(3-rows),	#the algorithm for printing spaces in the upper part of the diamond
        num=1
        while num<rows+1:
            print '\b'+str(num),	#the algorithm for printing numbers in upper part in diamond
            if num==rows:
                j=rows-1
                while j>0:		
                    print '\b'+str(j),	
                    j-=1
            num+=1
        print
        rows+=1
    rows=4
    while rows<6:
        print" "*(rows-3),	#the algorithm for printing spaces in the lower part of the diamond
        num=1
        while num<7-rows:
            print '\b'+str(num),
            if num==6-rows:
                j=5-rows
                while j>0:
                    print '\b'+str(j),
                    j-=1
            num+=1
        print
        rows+=1



