#to write a function named print_n_messages(m,n) to print the message m ,n times
def print_n_messages(m,n):
    i=0
    while i<n:
        print m		#printing the given message n times
        i+=1

