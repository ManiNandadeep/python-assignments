#to write a function named print_n_messages() to print "Hello world!" 10 times
def print_n_messages():
    n=0
    while n<10:
        print "Hello world!"	#printing Hello world! ten times
        n+=1

