#to write a function that prints stars in diamond fashion for 5 rows
def diamond():
    rows=1
    while rows<4:
        print " "*(3-rows) +"*"*(2*rows-1)
        rows+=1
    rows=4
    while rows<6:
        print " "*(rows-3) +"*"*(2*(5-rows)+1)
        rows+=1


