#to write a function named print_n_messages(m) to print message m 10 times
def print_n_messages(m):
    i=0
    while i<10:
        print m	#printing the given message ten times
        i+=1

        
