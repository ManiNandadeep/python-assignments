#to write a function to print the stars in diamond fashion of number of rows as odd
def diamond(n):
    rows=1
    while rows<(n+1)/2:
        if (n%2!=0):
            print " "*((n+1)/2-rows)+"*"*(2*rows-1)
        rows+=1
    rows=(n+1)/2
    while rows<n+1:
        if (n%2!=0):
            print " "*(rows-(n+1)/2)+"*"*(2*(n-rows)+1)
        rows+=1

