#to write a function to print character c in diamond fashion of height n
def diamond(n,c):
    rows=1
    while rows <(n+1)/2:
        if n%2!=0:
            print " "*((n+1)/2-rows)+c*(2*rows-1)
        rows+=1
    rows=(n+1)/2   
    while rows<n+1:
        if n%2!=0:
            print " "*(rows-(n+1)/2)+c*(2*(n-rows)+1)
        rows+=1

