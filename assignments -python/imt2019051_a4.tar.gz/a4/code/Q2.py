#to write a function named banner(m) that prints the message m decorated with borders
def banner(m):
    print "*"*(len(m)+4)
    print "* "+m+" *"
    print "*"*(len(m)+4)

