#to write a function named print_n_messages(n) such that it prints "Hello world!" n times
def print_n_messages(n):
    i=0
    while i<n:
        print "Hello world!" #printing the Hello wold! n times
        i+=1

