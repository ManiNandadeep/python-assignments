#to write a function named ndiamond(n) to print numbers in diamond fashion of height n
def ndiamond(n):
    if n%2!=0:			#checking whether the number is odd or not
        rows=1
        while rows<(n+3)/2:		#the algorithm for printing upper part of diamond
            print " "*((n+1)/2-rows),	#the algorithm for spaces
            num=1
            while num<rows+1:
                print '\b'+str(num),	#the algorithm for printing numbers in the upper part of the diamond
                if num==rows:
                    j=rows-1
                    while j >0:
                        print '\b'+str(j),	
                        j-=1
                num+=1
            rows+=1
            print
        rows=(n+3)/2
        while rows<n+1:
            print" "*(rows-(n+1)/2),		#the algorithm for printing lower part of diamond
            num=1
            while num<n+2-rows:
                print '\b'+str(num),		#the algorithm for printing numbers in the lower part of diamond
                if num==n+1-rows:
                    j=n-rows
                    while j>0:
                        print '\b'+str(j),
                        j-=1
                num+=1
            rows+=1
            print


