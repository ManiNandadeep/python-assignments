from Q4input import *

# Your code - begin
output = [] # should be [1,2,5,7,0,0] for the given input.
for i in inp:
    output=[nonzero for nonzero in inp if nonzero!=0]+[zero for zero in inp if zero==0] #first taking a list with nonzero elements using list comprehension and then adding the zeros 
# Your code - end
print output
