inp = "Plombez vingt fuyar!!!!"
