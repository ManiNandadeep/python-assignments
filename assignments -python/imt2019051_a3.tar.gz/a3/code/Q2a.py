from Q2input import *

# Your code - begin
output={}
for i in Dic1:
        output[i]=Dic1[i]   #creating a dictionary named output and adding the elements of Dic1

for i in Dic2:
        if i in output:
                output[i]+=Dic2[i]  #if the key is already present in output then add the values of them
        else:
                output[i]=Dic2[i]   #if the key is not present in output add it in output

# Your code - end
print output
