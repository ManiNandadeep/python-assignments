from Q6input import *

# Your code - begin
random={}
inp=inp.lower()
for i in inp:
    if i!=' 'and i!='\t'and i!='\n':
        if i not in random:
            random[i]=1
        else:
            random[i]+=1
list1=[]
for i in random:
    if random[i] not in list1:       #creating a list which appends the distinct values(frequencies) of random
        list1.append(random[i])
list1.sort()                    #arranging the frequencies in ascending order
required_frequency= list1[len(list1)-N]  #the numeric value of Nth most frequency
list2=[]
for i in random:
    if random[i]==required_frequency:
        list2.append(i)
least_ascii='z'
for i in list2:
    if i<least_ascii:               #to check the least ASCII character which suites the condition
        least_ascii=i
output="'"+least_ascii+"'"
#Your code - end
print output
