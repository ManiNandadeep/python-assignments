Dic1 = {'some': 5, 'fuzzy':25, 'data':15, 'logic':0}
Dic2 = {'some': 15, 'data':2, 'marks':100}
