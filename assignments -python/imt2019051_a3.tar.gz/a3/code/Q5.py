from Q5input import *

# Your code - begin
sets=[]
count=0
for l in set1:
    for m in set2:
        result=l+m
        sets.append(result)     #adding all the possible pairs
for i in sets:
    dic={}                      #creating a dictionary which checks whether the string is complete or not
    for j in i:
        if j not in dic:
            dic[j]=1            
        else:
            dic[j]+=1
    if len(dic)==26:
        count+=1
output=count
# Your code - end
print sets
print output
