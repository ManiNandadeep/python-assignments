inp = 'pythonissuchaeasylanguage'
N = 3
