from Q1input import *

# Your code - begin
output={}
for i in inp:
    if not i in output:   #checking whether i is in output or not
        output[i]=1
    else:
        output[i]+=1    #if i is already in output then increase the count

# Your code - end

print output
