from Q3input import *

# Your code - begin
temp={}
count=0
inp=inp.lower()     #converting all the uppercase letters to lowercase
output=False        #initialising the output to false
for i in inp:
    if (i>='a'and i<='z'):                  #checking whether i lies between ASCII values of a and z and negleting the special characters
        if i!=" " and i!="\t" and i!="\n" :
            if not i in temp:               
                temp[i]=1
         
            else:
                temp[i]+=1
for i in temp:
    if temp[i]!=1:                      #checking whether the element i is repeated or not 
        output=False
        break
    else:
        output=True

# Your code - end
print output
