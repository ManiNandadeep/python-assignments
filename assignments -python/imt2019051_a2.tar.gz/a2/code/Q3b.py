from Q3input import *

# Your code - begin
m=[]
i=0
while i<(len(m1[0])):
    a=[]
    j=0
    while j <(len(m1)):
        a.append(0)
        j+=1
    m.append(a)
    i+=1
i=0
while i< (len(m)):
    j=0
    while j < (len(m[0])):
        m[i][j]=m1[j][i]  #the algorithm for transposing a given matrix
        j+=1
    i+=1
output=m
# Your code - end
print output
