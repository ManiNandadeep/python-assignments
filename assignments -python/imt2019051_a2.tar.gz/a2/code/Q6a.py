from Q6input import *

# Your code - begin
#to find the mean of the given numbers
addition=0
i=0
while i <len(l):
    addition+=l[i]
    i+=1
mean = addition /float(len(l))  #here float take cares of the decimal places
output=mean
# Your code - end
print output
