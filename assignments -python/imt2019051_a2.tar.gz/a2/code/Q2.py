from Q2input import *

# Your code - begin
open_list=['[','{','(']     #creating a list named open_list which contain all types of open brackets 
close_list=[']','}',')']    #creating a list named close_list which contain all types of closed brackets to corresponding open bracket
stack=[]
i=0
while i<len(inp):
    x=inp[i]
    y=0
    while y<3:
        if x==close_list[y]:
            break
        y+=1
    if x in open_list:
        stack.append(x)     #if x is in open_list append x in stack
    elif x in close_list:
        if len(stack)!=0 and open_list[y]==stack[len(stack)-1]:
                stack.pop()
        else:
            output=False
            break
    i+=1
if len(stack)==0:
    output=True
else:
    output=False
# Your code - end
print output
