from Q4input import *

# Your code - begin
output = []
count=0
while(count<len(names)):
    inp=(names[count],English[count],Maths[count],DS[count],Physics[count]) #creating a tuple
    output.append(inp)
    count+=1
# Your code - end
print output
