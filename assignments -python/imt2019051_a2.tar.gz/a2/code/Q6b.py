from Q6input import *

# Your code - begin
#to find the median of given numbers
i=0
j=0
while i <len(l)-1:
    j=i+1
    while j<len(l):
        if l[i]>l[j]:
            t=l[i]
            l[i]=l[j]
            l[j]=t
        j+=1
    i+=1
if(len(l)%2!=0):
    output=l[(len(l)+1)/2]
if(len(l)%2==0):
    output =(l[len(l)/2]+l[len(l)/2+1])/2.0
# Your code - end
print output
