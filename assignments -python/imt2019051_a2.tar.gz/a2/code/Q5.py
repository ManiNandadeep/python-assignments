from Q5input import *

# Your code - begin
output = []
m=[]
i=0
j=0
while i <(n):
    m.append(l[i])
    i+=1
while j <(n):
    l.pop(0)
    j+=1       #removing the first element in the list
l.extend(m)
output=l
# Your code - end
print output
