from Q7input import *

# Your code - begin
l1.extend(l2)
i=0
j=0
while i <len(l1)-1:
    j=i+1
    while j<len(l1):       
        if l1[i]>l1[j]:           
            t=l1[i]             #introducing a temperary variable which stores l1[i]
            l1[i]=l1[j]
            l1[j]=t
        j+=1
    i+=1
output=l1
# Your code - end
print output
