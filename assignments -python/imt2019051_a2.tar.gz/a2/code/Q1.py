from Q1input import *

# Your code - begin
wordsize=0
output = "" # Your answer should be placed in this variable.
i=0
while i<len(inp):                               #going through the input
    ch=inp[i]                                       
    wordsize=wordsize+1                         #wordsize is the variable which counts the number of times a letter repeats
    if i==len(inp)-1:
        output=output+str(wordsize)+ch          
    else :
        if ch==inp[i+1]:                        
            pass
        else:                                   
            output=output+str(wordsize)+ch      #the output has word count followed by word
            wordsize=0
    i+=1
# Your code - end

print output
