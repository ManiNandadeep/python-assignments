from Q3input import *

# Your code - begin
m=[]
i=0
if len(m1[0])!=len(m2):
    print "The given matrices are not multiplicable"
else:    
    while i<len(m1):
        a=[]
        j=0
        while j<len(m2[0]):
            a.append(0)
            j+=1
        m.append(a)
        i+=1
    
    i=0
    while i<len(m1):
        j=0
        while j <len(m2[0]):
            k=0
            while k <len(m2):
                    m[i][j]+=m1[i][k]*m2[k][j] #the algorithm for matrix multiplication
                    k+=1
            j+=1        
        i+=1
output = m
# Your code - end
print output
